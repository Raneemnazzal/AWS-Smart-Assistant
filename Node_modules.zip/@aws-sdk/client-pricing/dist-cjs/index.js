const { awsEndpointFunctions, emitWarningIfUnsupportedVersion: emitWarningIfUnsupportedVersion$1, createDefaultUserAgentProvider, NODE_APP_ID_CONFIG_OPTIONS, getAwsRegionExtensionConfiguration, resolveAwsRegionExtensionConfiguration, resolveUserAgentConfig, resolveHostHeaderConfig, getUserAgentPlugin, getHostHeaderPlugin, getLoggerPlugin, getRecursionDetectionPlugin } = require("@aws-sdk/core/client");
const { getHttpAuthSchemeEndpointRuleSetPlugin, DefaultIdentityProviderConfig, getHttpSigningPlugin, createPaginator } = require("@smithy/core");
const { normalizeProvider, getSmithyContext, ServiceException, NoOpLogger, emitWarningIfUnsupportedVersion, loadConfigsForDefaultMode, getDefaultExtensionConfiguration, resolveDefaultRuntimeConfig, Client, makeBuilder, createAggregatedClient } = require("@smithy/core/client");
const { Command: $Command } = require("@smithy/core/client");
exports.$Command = $Command;
exports.__Client = Client;
const { resolveDefaultsModeConfig, loadConfig, NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, NODE_REGION_CONFIG_OPTIONS, NODE_REGION_CONFIG_FILE_OPTIONS, resolveRegionConfig } = require("@smithy/core/config");
const { BinaryDecisionDiagram, EndpointCache, decideEndpoint, customEndpointFunctions, resolveEndpointConfig, getEndpointPlugin } = require("@smithy/core/endpoints");
const { parseUrl, getHttpHandlerExtensionConfiguration, resolveHttpHandlerRuntimeConfig, getContentLengthPlugin } = require("@smithy/core/protocols");
const { DEFAULT_RETRY_MODE, NODE_RETRY_MODE_CONFIG_OPTIONS, NODE_MAX_ATTEMPT_CONFIG_OPTIONS, resolveRetryConfig, getRetryPlugin } = require("@smithy/core/retry");
const { TypeRegistry, getSchemaSerdePlugin } = require("@smithy/core/schema");
const { resolveAwsSdkSigV4Config, AwsSdkSigV4Signer, NODE_AUTH_SCHEME_PREFERENCE_OPTIONS } = require("@aws-sdk/core/httpAuthSchemes");
const { defaultProvider } = require("@aws-sdk/credential-provider-node");
const { toUtf8, fromUtf8, toBase64, fromBase64, calculateBodyLength } = require("@smithy/core/serde");
const { streamCollector, NodeHttpHandler } = require("@smithy/node-http-handler");
const { AwsJson1_1Protocol } = require("@aws-sdk/core/protocols");
const { Sha256 } = require("@smithy/core/checksum");

const defaultPricingHttpAuthSchemeParametersProvider = async (config, context, input) => {
    return {
        operation: getSmithyContext(context).operation,
        region: await normalizeProvider(config.region)() || (() => {
            throw new Error("expected `region` to be configured for `aws.auth#sigv4`");
        })(),
    };
};
function createAwsAuthSigv4HttpAuthOption(authParameters) {
    return {
        schemeId: "aws.auth#sigv4",
        signingProperties: {
            name: "pricing",
            region: authParameters.region,
        },
        propertiesExtractor: (config, context) => ({
            signingProperties: {
                config,
                context,
            },
        }),
    };
}
const defaultPricingHttpAuthSchemeProvider = (authParameters) => {
    const options = [];
    switch (authParameters.operation) {
        default: {
            options.push(createAwsAuthSigv4HttpAuthOption(authParameters));
        }
    }
    return options;
};
const resolveHttpAuthSchemeConfig = (config) => {
    const config_0 = resolveAwsSdkSigV4Config(config);
    return Object.assign(config_0, {
        authSchemePreference: normalizeProvider(config.authSchemePreference ?? []),
    });
};

const resolveClientEndpointParameters = (options) => {
    return Object.assign(options, {
        useDualstackEndpoint: options.useDualstackEndpoint ?? false,
        useFipsEndpoint: options.useFipsEndpoint ?? false,
        defaultSigningName: "pricing",
    });
};
const commonParams = {
    UseFIPS: { type: "builtInParams", name: "useFipsEndpoint" },
    Endpoint: { type: "builtInParams", name: "endpoint" },
    Region: { type: "builtInParams", name: "region" },
    UseDualStack: { type: "builtInParams", name: "useDualstackEndpoint" },
};

var version = "3.1140.0";
var packageInfo = {
	version: version};

const k = "ref";
const a = -1, b = true, c = "isSet", d = "PartitionResult", e = "booleanEquals", f = "getAttr", g = { [k]: "Endpoint" }, h = { [k]: d }, i = {}, j = [{ [k]: "Region" }];
const _data = {
    conditions: [
        [c, [g]],
        [c, j],
        ["aws.partition", j, d],
        [e, [{ [k]: "UseFIPS" }, b]],
        [e, [{ [k]: "UseDualStack" }, b]],
        [e, [{ fn: f, argv: [h, "supportsDualStack"] }, b]],
        [e, [{ fn: f, argv: [h, "supportsFIPS"] }, b]],
        ["stringEquals", [{ fn: f, argv: [h, "name"] }, "aws"]]
    ],
    results: [
        [a],
        [a, "Invalid Configuration: FIPS and custom endpoint are not supported"],
        [a, "Invalid Configuration: Dualstack and custom endpoint are not supported"],
        [g, i],
        ["https://api.pricing-fips.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
        [a, "FIPS and DualStack are enabled, but this partition does not support one or both"],
        ["https://api.pricing-fips.{Region}.{PartitionResult#dnsSuffix}", i],
        [a, "FIPS is enabled but this partition does not support FIPS"],
        ["https://api.pricing.{Region}.{PartitionResult#dualStackDnsSuffix}", i],
        [a, "DualStack is enabled but this partition does not support DualStack"],
        ["https://api.pricing.{Region}.amazonaws.com", i],
        ["https://api.pricing.{Region}.{PartitionResult#dnsSuffix}", i],
        [a, "Invalid Configuration: Missing Region"]
    ]
};
const root = 2;
const r = 100_000_000;
const nodes = new Int32Array([
    -1, 1, -1,
    0, 13, 3,
    1, 4, r + 12,
    2, 5, r + 12,
    3, 9, 6,
    4, 8, 7,
    7, r + 10, r + 11,
    5, r + 8, r + 9,
    4, 11, 10,
    6, r + 6, r + 7,
    5, 12, r + 5,
    6, r + 4, r + 5,
    3, r + 1, 14,
    4, r + 2, r + 3,
]);
const bdd = BinaryDecisionDiagram.from(nodes, root, _data.conditions, _data.results);

const cache = new EndpointCache({
    size: 50,
    params: ["Endpoint", "Region", "UseDualStack", "UseFIPS"],
});
const defaultEndpointResolver = (endpointParams, context = {}) => {
    return cache.get(endpointParams, () => decideEndpoint(bdd, {
        endpointParams: endpointParams,
        logger: context.logger,
    }));
};
customEndpointFunctions.aws = awsEndpointFunctions;

class PricingServiceException extends ServiceException {
    constructor(options) {
        super(options);
        Object.setPrototypeOf(this, PricingServiceException.prototype);
    }
}

class AccessDeniedException extends PricingServiceException {
    name = "AccessDeniedException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "AccessDeniedException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, AccessDeniedException.prototype);
        this.Message = opts.Message;
    }
}
class ExpiredNextTokenException extends PricingServiceException {
    name = "ExpiredNextTokenException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ExpiredNextTokenException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ExpiredNextTokenException.prototype);
        this.Message = opts.Message;
    }
}
class InternalErrorException extends PricingServiceException {
    name = "InternalErrorException";
    $fault = "server";
    $retryable = {};
    Message;
    constructor(opts) {
        super({
            name: "InternalErrorException",
            $fault: "server",
            ...opts,
        });
        Object.setPrototypeOf(this, InternalErrorException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidNextTokenException extends PricingServiceException {
    name = "InvalidNextTokenException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidNextTokenException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidNextTokenException.prototype);
        this.Message = opts.Message;
    }
}
class InvalidParameterException extends PricingServiceException {
    name = "InvalidParameterException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "InvalidParameterException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, InvalidParameterException.prototype);
        this.Message = opts.Message;
    }
}
class NotFoundException extends PricingServiceException {
    name = "NotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "NotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, NotFoundException.prototype);
        this.Message = opts.Message;
    }
}
class ThrottlingException extends PricingServiceException {
    name = "ThrottlingException";
    $fault = "client";
    $retryable = {
        throttling: true,
    };
    Message;
    constructor(opts) {
        super({
            name: "ThrottlingException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ThrottlingException.prototype);
        this.Message = opts.Message;
    }
}
class ResourceNotFoundException extends PricingServiceException {
    name = "ResourceNotFoundException";
    $fault = "client";
    Message;
    constructor(opts) {
        super({
            name: "ResourceNotFoundException",
            $fault: "client",
            ...opts,
        });
        Object.setPrototypeOf(this, ResourceNotFoundException.prototype);
        this.Message = opts.Message;
    }
}

const _ADE = "AccessDeniedException";
const _AN = "AttributeName";
const _ANt = "AttributeNames";
const _AV = "AttributeValue";
const _AVL = "AttributeValueList";
const _AVt = "AttributeValues";
const _CC = "CurrencyCode";
const _DS = "DescribeServices";
const _DSR = "DescribeServicesRequest";
const _DSRe = "DescribeServicesResponse";
const _ED = "EffectiveDate";
const _ENTE = "ExpiredNextTokenException";
const _F = "Filter";
const _FF = "FileFormat";
const _FFi = "FileFormats";
const _FV = "FormatVersion";
const _Fi = "Field";
const _Fil = "Filters";
const _GAV = "GetAttributeValues";
const _GAVR = "GetAttributeValuesRequest";
const _GAVRe = "GetAttributeValuesResponse";
const _GP = "GetProducts";
const _GPLFU = "GetPriceListFileUrl";
const _GPLFUR = "GetPriceListFileUrlRequest";
const _GPLFURe = "GetPriceListFileUrlResponse";
const _GPR = "GetProductsRequest";
const _GPRe = "GetProductsResponse";
const _IEE = "InternalErrorException";
const _INTE = "InvalidNextTokenException";
const _IPE = "InvalidParameterException";
const _LPL = "ListPriceLists";
const _LPLR = "ListPriceListsRequest";
const _LPLRi = "ListPriceListsResponse";
const _M = "Message";
const _MR = "MaxResults";
const _NFE = "NotFoundException";
const _NT = "NextToken";
const _PL = "PriceList";
const _PLA = "PriceListArn";
const _PLJI = "PriceListJsonItems";
const _PLr = "PriceLists";
const _RC = "RegionCode";
const _RNFE = "ResourceNotFoundException";
const _S = "Services";
const _SC = "ServiceCode";
const _SJPLJI = "SynthesizedJsonPriceListJsonItem";
const _SL = "ServiceList";
const _Se = "Service";
const _T = "Type";
const _TE = "ThrottlingException";
const _U = "Url";
const _V = "Value";
const _a = "application/json";
const _c = "client";
const _e = "error";
const _hE = "httpError";
const _mT = "mediaType";
const _s = "smithy.ts.sdk.synthetic.com.amazonaws.pricing";
const _se = "server";
const n0 = "com.amazonaws.pricing";
const _s_registry = new TypeRegistry(_s);
var PricingServiceException$ = [-3, _s, "PricingServiceException", 0, [], []];
_s_registry.registerError(PricingServiceException$, PricingServiceException);
const n0_registry = new TypeRegistry(n0);
var AccessDeniedException$ = [-3, n0, _ADE,
    { [_e]: _c, [_hE]: 401 },
    [_M],
    [0]
];
n0_registry.registerError(AccessDeniedException$, AccessDeniedException);
var ExpiredNextTokenException$ = [-3, n0, _ENTE,
    { [_e]: _c, [_hE]: 400 },
    [_M],
    [0]
];
n0_registry.registerError(ExpiredNextTokenException$, ExpiredNextTokenException);
var InternalErrorException$ = [-3, n0, _IEE,
    { [_e]: _se, [_hE]: 500 },
    [_M],
    [0]
];
n0_registry.registerError(InternalErrorException$, InternalErrorException);
var InvalidNextTokenException$ = [-3, n0, _INTE,
    { [_e]: _c, [_hE]: 400 },
    [_M],
    [0]
];
n0_registry.registerError(InvalidNextTokenException$, InvalidNextTokenException);
var InvalidParameterException$ = [-3, n0, _IPE,
    { [_e]: _c, [_hE]: 400 },
    [_M],
    [0]
];
n0_registry.registerError(InvalidParameterException$, InvalidParameterException);
var NotFoundException$ = [-3, n0, _NFE,
    { [_e]: _c, [_hE]: 400 },
    [_M],
    [0]
];
n0_registry.registerError(NotFoundException$, NotFoundException);
var ResourceNotFoundException$ = [-3, n0, _RNFE,
    { [_e]: _c, [_hE]: 404 },
    [_M],
    [0]
];
n0_registry.registerError(ResourceNotFoundException$, ResourceNotFoundException);
var ThrottlingException$ = [-3, n0, _TE,
    { [_e]: _c, [_hE]: 429 },
    [_M],
    [0]
];
n0_registry.registerError(ThrottlingException$, ThrottlingException);
const errorTypeRegistries = [
    _s_registry,
    n0_registry,
];
var SynthesizedJsonPriceListJsonItem = [0, n0, _SJPLJI, { [_mT]: _a }, 0];
var AttributeValue$ = [3, n0, _AV,
    0,
    [_V],
    [0]
];
var DescribeServicesRequest$ = [3, n0, _DSR,
    0,
    [_SC, _FV, _NT, _MR],
    [0, 0, 0, 1]
];
var DescribeServicesResponse$ = [3, n0, _DSRe,
    0,
    [_S, _FV, _NT],
    [() => ServiceList, 0, 0]
];
var Filter$ = [3, n0, _F,
    0,
    [_T, _Fi, _V],
    [0, 0, 0], 3
];
var GetAttributeValuesRequest$ = [3, n0, _GAVR,
    0,
    [_SC, _AN, _NT, _MR],
    [0, 0, 0, 1], 2
];
var GetAttributeValuesResponse$ = [3, n0, _GAVRe,
    0,
    [_AVt, _NT],
    [() => AttributeValueList, 0]
];
var GetPriceListFileUrlRequest$ = [3, n0, _GPLFUR,
    0,
    [_PLA, _FF],
    [0, 0], 2
];
var GetPriceListFileUrlResponse$ = [3, n0, _GPLFURe,
    0,
    [_U],
    [0]
];
var GetProductsRequest$ = [3, n0, _GPR,
    0,
    [_SC, _Fil, _FV, _NT, _MR],
    [0, () => Filters, 0, 0, 1], 1
];
var GetProductsResponse$ = [3, n0, _GPRe,
    0,
    [_FV, _PL, _NT],
    [0, [() => PriceListJsonItems, 0], 0]
];
var ListPriceListsRequest$ = [3, n0, _LPLR,
    0,
    [_SC, _ED, _CC, _RC, _NT, _MR],
    [0, 4, 0, 0, 0, 1], 3
];
var ListPriceListsResponse$ = [3, n0, _LPLRi,
    0,
    [_PLr, _NT],
    [() => PriceLists, 0]
];
var PriceList$ = [3, n0, _PL,
    0,
    [_PLA, _RC, _CC, _FFi],
    [0, 0, 0, 64 | 0]
];
var Service$ = [3, n0, _Se,
    0,
    [_SC, _ANt],
    [0, 64 | 0], 1
];
var AttributeValueList = [1, n0, _AVL,
    0, () => AttributeValue$
];
var Filters = [1, n0, _Fil,
    0, () => Filter$
];
var PriceListJsonItems = [1, n0, _PLJI,
    0, [() => SynthesizedJsonPriceListJsonItem,
        0]
];
var PriceLists = [1, n0, _PLr,
    0, () => PriceList$
];
var ServiceList = [1, n0, _SL,
    0, () => Service$
];
var DescribeServices$ = [9, n0, _DS,
    0, () => DescribeServicesRequest$, () => DescribeServicesResponse$
];
var GetAttributeValues$ = [9, n0, _GAV,
    0, () => GetAttributeValuesRequest$, () => GetAttributeValuesResponse$
];
var GetPriceListFileUrl$ = [9, n0, _GPLFU,
    0, () => GetPriceListFileUrlRequest$, () => GetPriceListFileUrlResponse$
];
var GetProducts$ = [9, n0, _GP,
    0, () => GetProductsRequest$, () => GetProductsResponse$
];
var ListPriceLists$ = [9, n0, _LPL,
    0, () => ListPriceListsRequest$, () => ListPriceListsResponse$
];

const getRuntimeConfig$1 = (config) => {
    return {
        apiVersion: "2017-10-15",
        base64Decoder: config?.base64Decoder ?? fromBase64,
        base64Encoder: config?.base64Encoder ?? toBase64,
        disableHostPrefix: config?.disableHostPrefix ?? false,
        endpointProvider: config?.endpointProvider ?? defaultEndpointResolver,
        extensions: config?.extensions ?? [],
        httpAuthSchemeProvider: config?.httpAuthSchemeProvider ?? defaultPricingHttpAuthSchemeProvider,
        httpAuthSchemes: config?.httpAuthSchemes ?? [
            {
                schemeId: "aws.auth#sigv4",
                identityProvider: (ipc) => ipc.getIdentityProvider("aws.auth#sigv4"),
                signer: new AwsSdkSigV4Signer(),
            },
        ],
        logger: config?.logger ?? new NoOpLogger(),
        protocol: config?.protocol ?? AwsJson1_1Protocol,
        protocolSettings: config?.protocolSettings ?? {
            defaultNamespace: "com.amazonaws.pricing",
            errorTypeRegistries,
            version: "2017-10-15",
            serviceTarget: "AWSPriceListService",
        },
        serviceId: config?.serviceId ?? "Pricing",
        sha256: config?.sha256 ?? Sha256,
        urlParser: config?.urlParser ?? parseUrl,
        utf8Decoder: config?.utf8Decoder ?? fromUtf8,
        utf8Encoder: config?.utf8Encoder ?? toUtf8,
    };
};

const getRuntimeConfig = (config) => {
    emitWarningIfUnsupportedVersion(process.version);
    const defaultsMode = resolveDefaultsModeConfig(config);
    const defaultConfigProvider = () => defaultsMode().then(loadConfigsForDefaultMode);
    const clientSharedValues = getRuntimeConfig$1(config);
    emitWarningIfUnsupportedVersion$1(process.version);
    const loaderConfig = {
        profile: config?.profile,
        logger: clientSharedValues.logger,
    };
    return {
        ...clientSharedValues,
        ...config,
        runtime: "node",
        defaultsMode,
        authSchemePreference: config?.authSchemePreference ?? loadConfig(NODE_AUTH_SCHEME_PREFERENCE_OPTIONS, loaderConfig),
        bodyLengthChecker: config?.bodyLengthChecker ?? calculateBodyLength,
        credentialDefaultProvider: config?.credentialDefaultProvider ?? defaultProvider,
        defaultUserAgentProvider: config?.defaultUserAgentProvider ?? createDefaultUserAgentProvider({ serviceId: clientSharedValues.serviceId, clientVersion: packageInfo.version }),
        maxAttempts: config?.maxAttempts ?? loadConfig(NODE_MAX_ATTEMPT_CONFIG_OPTIONS, config),
        region: config?.region ?? loadConfig(NODE_REGION_CONFIG_OPTIONS, { ...NODE_REGION_CONFIG_FILE_OPTIONS, ...loaderConfig }),
        requestHandler: NodeHttpHandler.create(config?.requestHandler ?? defaultConfigProvider),
        retryMode: config?.retryMode ??
            loadConfig({
                ...NODE_RETRY_MODE_CONFIG_OPTIONS,
                default: async () => (await defaultConfigProvider()).retryMode || DEFAULT_RETRY_MODE,
            }, config),
        streamCollector: config?.streamCollector ?? streamCollector,
        useDualstackEndpoint: config?.useDualstackEndpoint ?? loadConfig(NODE_USE_DUALSTACK_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        useFipsEndpoint: config?.useFipsEndpoint ?? loadConfig(NODE_USE_FIPS_ENDPOINT_CONFIG_OPTIONS, loaderConfig),
        userAgentAppId: config?.userAgentAppId ?? loadConfig(NODE_APP_ID_CONFIG_OPTIONS, loaderConfig),
    };
};

const getHttpAuthExtensionConfiguration = (runtimeConfig) => {
    const _httpAuthSchemes = runtimeConfig.httpAuthSchemes;
    let _httpAuthSchemeProvider = runtimeConfig.httpAuthSchemeProvider;
    let _credentials = runtimeConfig.credentials;
    return {
        setHttpAuthScheme(httpAuthScheme) {
            const index = _httpAuthSchemes.findIndex((scheme) => scheme.schemeId === httpAuthScheme.schemeId);
            if (index === -1) {
                _httpAuthSchemes.push(httpAuthScheme);
            }
            else {
                _httpAuthSchemes.splice(index, 1, httpAuthScheme);
            }
        },
        httpAuthSchemes() {
            return _httpAuthSchemes;
        },
        setHttpAuthSchemeProvider(httpAuthSchemeProvider) {
            _httpAuthSchemeProvider = httpAuthSchemeProvider;
        },
        httpAuthSchemeProvider() {
            return _httpAuthSchemeProvider;
        },
        setCredentials(credentials) {
            _credentials = credentials;
        },
        credentials() {
            return _credentials;
        },
    };
};
const resolveHttpAuthRuntimeConfig = (config) => {
    return {
        httpAuthSchemes: config.httpAuthSchemes(),
        httpAuthSchemeProvider: config.httpAuthSchemeProvider(),
        credentials: config.credentials(),
    };
};

const resolveRuntimeExtensions = (runtimeConfig, extensions) => {
    const extensionConfiguration = Object.assign(getAwsRegionExtensionConfiguration(runtimeConfig), getDefaultExtensionConfiguration(runtimeConfig), getHttpHandlerExtensionConfiguration(runtimeConfig), getHttpAuthExtensionConfiguration(runtimeConfig));
    extensions.forEach((extension) => extension.configure(extensionConfiguration));
    return Object.assign(runtimeConfig, resolveAwsRegionExtensionConfiguration(extensionConfiguration), resolveDefaultRuntimeConfig(extensionConfiguration), resolveHttpHandlerRuntimeConfig(extensionConfiguration), resolveHttpAuthRuntimeConfig(extensionConfiguration));
};

class PricingClient extends Client {
    config;
    constructor(...[configuration]) {
        const _config_0 = getRuntimeConfig(configuration || {});
        super(_config_0);
        this.initConfig = _config_0;
        const _config_1 = resolveClientEndpointParameters(_config_0);
        const _config_2 = resolveUserAgentConfig(_config_1);
        const _config_3 = resolveRetryConfig(_config_2);
        const _config_4 = resolveRegionConfig(_config_3);
        const _config_5 = resolveHostHeaderConfig(_config_4);
        const _config_6 = resolveEndpointConfig(_config_5);
        const _config_7 = resolveHttpAuthSchemeConfig(_config_6);
        const _config_8 = resolveRuntimeExtensions(_config_7, configuration?.extensions || []);
        this.config = _config_8;
        this.middlewareStack.use(getSchemaSerdePlugin(this.config));
        this.middlewareStack.use(getUserAgentPlugin(this.config));
        this.middlewareStack.use(getRetryPlugin(this.config));
        this.middlewareStack.use(getContentLengthPlugin(this.config));
        this.middlewareStack.use(getHostHeaderPlugin(this.config));
        this.middlewareStack.use(getLoggerPlugin(this.config));
        this.middlewareStack.use(getRecursionDetectionPlugin(this.config));
        this.middlewareStack.use(getHttpAuthSchemeEndpointRuleSetPlugin(this.config, {
            httpAuthSchemeParametersProvider: defaultPricingHttpAuthSchemeParametersProvider,
            identityProviderConfigProvider: async (config) => new DefaultIdentityProviderConfig({
                "aws.auth#sigv4": config.credentials,
            }),
        }));
        this.middlewareStack.use(getHttpSigningPlugin(this.config));
    }
    destroy() {
        super.destroy();
    }
}

const command = makeBuilder(commonParams, "AWSPriceListService", "PricingClient", getEndpointPlugin);
const _ep0 = {};
const _mw0 = (Command, cs, config, o) => [];

class DescribeServicesCommand extends command(_ep0, _mw0, "DescribeServices", DescribeServices$) {
}

class GetAttributeValuesCommand extends command(_ep0, _mw0, "GetAttributeValues", GetAttributeValues$) {
}

class GetPriceListFileUrlCommand extends command(_ep0, _mw0, "GetPriceListFileUrl", GetPriceListFileUrl$) {
}

class GetProductsCommand extends command(_ep0, _mw0, "GetProducts", GetProducts$) {
}

class ListPriceListsCommand extends command(_ep0, _mw0, "ListPriceLists", ListPriceLists$) {
}

const paginateDescribeServices = createPaginator(PricingClient, DescribeServicesCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetAttributeValues = createPaginator(PricingClient, GetAttributeValuesCommand, "NextToken", "NextToken", "MaxResults");

const paginateGetProducts = createPaginator(PricingClient, GetProductsCommand, "NextToken", "NextToken", "MaxResults");

const paginateListPriceLists = createPaginator(PricingClient, ListPriceListsCommand, "NextToken", "NextToken", "MaxResults");

const commands = {
    DescribeServicesCommand,
    GetAttributeValuesCommand,
    GetPriceListFileUrlCommand,
    GetProductsCommand,
    ListPriceListsCommand,
};
const paginators = {
    paginateDescribeServices,
    paginateGetAttributeValues,
    paginateGetProducts,
    paginateListPriceLists,
};
class Pricing extends PricingClient {
}
createAggregatedClient(commands, Pricing, { paginators });

const FilterType = {
    ANY_OF: "ANY_OF",
    CONTAINS: "CONTAINS",
    EQUALS: "EQUALS",
    NONE_OF: "NONE_OF",
    TERM_MATCH: "TERM_MATCH",
};

exports.AccessDeniedException = AccessDeniedException;
exports.AccessDeniedException$ = AccessDeniedException$;
exports.AttributeValue$ = AttributeValue$;
exports.DescribeServices$ = DescribeServices$;
exports.DescribeServicesCommand = DescribeServicesCommand;
exports.DescribeServicesRequest$ = DescribeServicesRequest$;
exports.DescribeServicesResponse$ = DescribeServicesResponse$;
exports.ExpiredNextTokenException = ExpiredNextTokenException;
exports.ExpiredNextTokenException$ = ExpiredNextTokenException$;
exports.Filter$ = Filter$;
exports.FilterType = FilterType;
exports.GetAttributeValues$ = GetAttributeValues$;
exports.GetAttributeValuesCommand = GetAttributeValuesCommand;
exports.GetAttributeValuesRequest$ = GetAttributeValuesRequest$;
exports.GetAttributeValuesResponse$ = GetAttributeValuesResponse$;
exports.GetPriceListFileUrl$ = GetPriceListFileUrl$;
exports.GetPriceListFileUrlCommand = GetPriceListFileUrlCommand;
exports.GetPriceListFileUrlRequest$ = GetPriceListFileUrlRequest$;
exports.GetPriceListFileUrlResponse$ = GetPriceListFileUrlResponse$;
exports.GetProducts$ = GetProducts$;
exports.GetProductsCommand = GetProductsCommand;
exports.GetProductsRequest$ = GetProductsRequest$;
exports.GetProductsResponse$ = GetProductsResponse$;
exports.InternalErrorException = InternalErrorException;
exports.InternalErrorException$ = InternalErrorException$;
exports.InvalidNextTokenException = InvalidNextTokenException;
exports.InvalidNextTokenException$ = InvalidNextTokenException$;
exports.InvalidParameterException = InvalidParameterException;
exports.InvalidParameterException$ = InvalidParameterException$;
exports.ListPriceLists$ = ListPriceLists$;
exports.ListPriceListsCommand = ListPriceListsCommand;
exports.ListPriceListsRequest$ = ListPriceListsRequest$;
exports.ListPriceListsResponse$ = ListPriceListsResponse$;
exports.NotFoundException = NotFoundException;
exports.NotFoundException$ = NotFoundException$;
exports.PriceList$ = PriceList$;
exports.Pricing = Pricing;
exports.PricingClient = PricingClient;
exports.PricingServiceException = PricingServiceException;
exports.PricingServiceException$ = PricingServiceException$;
exports.ResourceNotFoundException = ResourceNotFoundException;
exports.ResourceNotFoundException$ = ResourceNotFoundException$;
exports.Service$ = Service$;
exports.ThrottlingException = ThrottlingException;
exports.ThrottlingException$ = ThrottlingException$;
exports.errorTypeRegistries = errorTypeRegistries;
exports.paginateDescribeServices = paginateDescribeServices;
exports.paginateGetAttributeValues = paginateGetAttributeValues;
exports.paginateGetProducts = paginateGetProducts;
exports.paginateListPriceLists = paginateListPriceLists;
