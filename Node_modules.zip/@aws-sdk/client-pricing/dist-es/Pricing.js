import { createAggregatedClient } from "@smithy/core/client";
import { DescribeServicesCommand, } from "./commands/DescribeServicesCommand";
import { GetAttributeValuesCommand, } from "./commands/GetAttributeValuesCommand";
import { GetPriceListFileUrlCommand, } from "./commands/GetPriceListFileUrlCommand";
import { GetProductsCommand, } from "./commands/GetProductsCommand";
import { ListPriceListsCommand, } from "./commands/ListPriceListsCommand";
import { paginateDescribeServices } from "./pagination/DescribeServicesPaginator";
import { paginateGetAttributeValues } from "./pagination/GetAttributeValuesPaginator";
import { paginateGetProducts } from "./pagination/GetProductsPaginator";
import { paginateListPriceLists } from "./pagination/ListPriceListsPaginator";
import { PricingClient } from "./PricingClient";
const commands = {
    DescribeServicesCommand,
    GetAttributeValuesCommand,
    GetPriceListFileUrlCommand,
    GetProductsCommand,
    ListPriceListsCommand,
};
const paginators = {
    paginateDescribeServices,
    paginateGetAttributeValues,
    paginateGetProducts,
    paginateListPriceLists,
};
export class Pricing extends PricingClient {
}
createAggregatedClient(commands, Pricing, { paginators });
