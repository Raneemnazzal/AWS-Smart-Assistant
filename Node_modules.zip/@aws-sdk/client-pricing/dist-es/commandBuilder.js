import { makeBuilder } from "@smithy/core/client";
import { getEndpointPlugin } from "@smithy/core/endpoints";
import { commonParams } from "./endpoint/EndpointParameters";
export const command = makeBuilder(commonParams, "AWSPriceListService", "PricingClient", getEndpointPlugin);
export const _ep0 = {};
export const _mw0 = (Command, cs, config, o) => [];
