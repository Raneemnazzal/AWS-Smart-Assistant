import { _ep0, _mw0, command } from "../commandBuilder";
import { DescribeServices$ } from "../schemas/schemas_0";
export class DescribeServicesCommand extends command(_ep0, _mw0, "DescribeServices", DescribeServices$) {
}
