import { _ep0, _mw0, command } from "../commandBuilder";
import { GetAttributeValues$ } from "../schemas/schemas_0";
export class GetAttributeValuesCommand extends command(_ep0, _mw0, "GetAttributeValues", GetAttributeValues$) {
}
