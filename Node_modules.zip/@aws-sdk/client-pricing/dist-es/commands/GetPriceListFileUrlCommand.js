import { _ep0, _mw0, command } from "../commandBuilder";
import { GetPriceListFileUrl$ } from "../schemas/schemas_0";
export class GetPriceListFileUrlCommand extends command(_ep0, _mw0, "GetPriceListFileUrl", GetPriceListFileUrl$) {
}
