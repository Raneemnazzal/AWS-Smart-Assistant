import { _ep0, _mw0, command } from "../commandBuilder";
import { GetProducts$ } from "../schemas/schemas_0";
export class GetProductsCommand extends command(_ep0, _mw0, "GetProducts", GetProducts$) {
}
