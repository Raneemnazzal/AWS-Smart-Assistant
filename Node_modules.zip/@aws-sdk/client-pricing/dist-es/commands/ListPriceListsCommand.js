import { _ep0, _mw0, command } from "../commandBuilder";
import { ListPriceLists$ } from "../schemas/schemas_0";
export class ListPriceListsCommand extends command(_ep0, _mw0, "ListPriceLists", ListPriceLists$) {
}
