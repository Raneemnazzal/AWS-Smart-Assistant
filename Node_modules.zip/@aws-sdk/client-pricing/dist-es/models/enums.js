export const FilterType = {
    ANY_OF: "ANY_OF",
    CONTAINS: "CONTAINS",
    EQUALS: "EQUALS",
    NONE_OF: "NONE_OF",
    TERM_MATCH: "TERM_MATCH",
};
