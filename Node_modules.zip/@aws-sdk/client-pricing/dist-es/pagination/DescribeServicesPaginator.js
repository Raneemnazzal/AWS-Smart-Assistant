import { createPaginator } from "@smithy/core";
import { DescribeServicesCommand, } from "../commands/DescribeServicesCommand";
import { PricingClient } from "../PricingClient";
export const paginateDescribeServices = createPaginator(PricingClient, DescribeServicesCommand, "NextToken", "NextToken", "MaxResults");
