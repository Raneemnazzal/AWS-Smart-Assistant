import { createPaginator } from "@smithy/core";
import { GetAttributeValuesCommand, } from "../commands/GetAttributeValuesCommand";
import { PricingClient } from "../PricingClient";
export const paginateGetAttributeValues = createPaginator(PricingClient, GetAttributeValuesCommand, "NextToken", "NextToken", "MaxResults");
