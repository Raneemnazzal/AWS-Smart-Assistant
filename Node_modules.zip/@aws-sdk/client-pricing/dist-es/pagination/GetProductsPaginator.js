import { createPaginator } from "@smithy/core";
import { GetProductsCommand } from "../commands/GetProductsCommand";
import { PricingClient } from "../PricingClient";
export const paginateGetProducts = createPaginator(PricingClient, GetProductsCommand, "NextToken", "NextToken", "MaxResults");
