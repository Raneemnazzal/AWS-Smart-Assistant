import { createPaginator } from "@smithy/core";
import { ListPriceListsCommand, } from "../commands/ListPriceListsCommand";
import { PricingClient } from "../PricingClient";
export const paginateListPriceLists = createPaginator(PricingClient, ListPriceListsCommand, "NextToken", "NextToken", "MaxResults");
