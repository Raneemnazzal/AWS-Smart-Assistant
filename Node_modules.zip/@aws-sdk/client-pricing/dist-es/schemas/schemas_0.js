const _ADE = "AccessDeniedException";
const _AN = "AttributeName";
const _ANt = "AttributeNames";
const _AV = "AttributeValue";
const _AVL = "AttributeValueList";
const _AVt = "AttributeValues";
const _CC = "CurrencyCode";
const _DS = "DescribeServices";
const _DSR = "DescribeServicesRequest";
const _DSRe = "DescribeServicesResponse";
const _ED = "EffectiveDate";
const _ENTE = "ExpiredNextTokenException";
const _F = "Filter";
const _FF = "FileFormat";
const _FFi = "FileFormats";
const _FV = "FormatVersion";
const _Fi = "Field";
const _Fil = "Filters";
const _GAV = "GetAttributeValues";
const _GAVR = "GetAttributeValuesRequest";
const _GAVRe = "GetAttributeValuesResponse";
const _GP = "GetProducts";
const _GPLFU = "GetPriceListFileUrl";
const _GPLFUR = "GetPriceListFileUrlRequest";
const _GPLFURe = "GetPriceListFileUrlResponse";
const _GPR = "GetProductsRequest";
const _GPRe = "GetProductsResponse";
const _IEE = "InternalErrorException";
const _INTE = "InvalidNextTokenException";
const _IPE = "InvalidParameterException";
const _LPL = "ListPriceLists";
const _LPLR = "ListPriceListsRequest";
const _LPLRi = "ListPriceListsResponse";
const _M = "Message";
const _MR = "MaxResults";
const _NFE = "NotFoundException";
const _NT = "NextToken";
const _PL = "PriceList";
const _PLA = "PriceListArn";
const _PLJI = "PriceListJsonItems";
const _PLr = "PriceLists";
const _RC = "RegionCode";
const _RNFE = "ResourceNotFoundException";
const _S = "Services";
const _SC = "ServiceCode";
const _SJPLJI = "SynthesizedJsonPriceListJsonItem";
const _SL = "ServiceList";
const _Se = "Service";
const _T = "Type";
const _TE = "ThrottlingException";
const _U = "Url";
const _V = "Value";
const _a = "application/json";
const _c = "client";
const _e = "error";
const _hE = "httpError";
const _mT = "mediaType";
const _s = "smithy.ts.sdk.synthetic.com.amazonaws.pricing";
const _se = "server";
const n0 = "com.amazonaws.pricing";
import { TypeRegistry } from "@smithy/core/schema";
import { AccessDeniedException, ExpiredNextTokenException, InternalErrorException, InvalidNextTokenException, InvalidParameterException, NotFoundException, ResourceNotFoundException, ThrottlingException, } from "../models/errors";
import { PricingServiceException } from "../models/PricingServiceException";
const _s_registry = new TypeRegistry(_s);
export var PricingServiceException$ = [-3, _s, "PricingServiceException", 0, [], []];
_s_registry.registerError(PricingServiceException$, PricingServiceException);
const n0_registry = new TypeRegistry(n0);
export var AccessDeniedException$ = [-3, n0, _ADE,
    { [_e]: _c, [_hE]: 401 },
    [_M],
    [0]
];
n0_registry.registerError(AccessDeniedException$, AccessDeniedException);
export var ExpiredNextTokenException$ = [-3, n0, _ENTE,
    { [_e]: _c, [_hE]: 400 },
    [_M],
    [0]
];
n0_registry.registerError(ExpiredNextTokenException$, ExpiredNextTokenException);
export var InternalErrorException$ = [-3, n0, _IEE,
    { [_e]: _se, [_hE]: 500 },
    [_M],
    [0]
];
n0_registry.registerError(InternalErrorException$, InternalErrorException);
export var InvalidNextTokenException$ = [-3, n0, _INTE,
    { [_e]: _c, [_hE]: 400 },
    [_M],
    [0]
];
n0_registry.registerError(InvalidNextTokenException$, InvalidNextTokenException);
export var InvalidParameterException$ = [-3, n0, _IPE,
    { [_e]: _c, [_hE]: 400 },
    [_M],
    [0]
];
n0_registry.registerError(InvalidParameterException$, InvalidParameterException);
export var NotFoundException$ = [-3, n0, _NFE,
    { [_e]: _c, [_hE]: 400 },
    [_M],
    [0]
];
n0_registry.registerError(NotFoundException$, NotFoundException);
export var ResourceNotFoundException$ = [-3, n0, _RNFE,
    { [_e]: _c, [_hE]: 404 },
    [_M],
    [0]
];
n0_registry.registerError(ResourceNotFoundException$, ResourceNotFoundException);
export var ThrottlingException$ = [-3, n0, _TE,
    { [_e]: _c, [_hE]: 429 },
    [_M],
    [0]
];
n0_registry.registerError(ThrottlingException$, ThrottlingException);
export const errorTypeRegistries = [
    _s_registry,
    n0_registry,
];
var SynthesizedJsonPriceListJsonItem = [0, n0, _SJPLJI, { [_mT]: _a }, 0];
export var AttributeValue$ = [3, n0, _AV,
    0,
    [_V],
    [0]
];
export var DescribeServicesRequest$ = [3, n0, _DSR,
    0,
    [_SC, _FV, _NT, _MR],
    [0, 0, 0, 1]
];
export var DescribeServicesResponse$ = [3, n0, _DSRe,
    0,
    [_S, _FV, _NT],
    [() => ServiceList, 0, 0]
];
export var Filter$ = [3, n0, _F,
    0,
    [_T, _Fi, _V],
    [0, 0, 0], 3
];
export var GetAttributeValuesRequest$ = [3, n0, _GAVR,
    0,
    [_SC, _AN, _NT, _MR],
    [0, 0, 0, 1], 2
];
export var GetAttributeValuesResponse$ = [3, n0, _GAVRe,
    0,
    [_AVt, _NT],
    [() => AttributeValueList, 0]
];
export var GetPriceListFileUrlRequest$ = [3, n0, _GPLFUR,
    0,
    [_PLA, _FF],
    [0, 0], 2
];
export var GetPriceListFileUrlResponse$ = [3, n0, _GPLFURe,
    0,
    [_U],
    [0]
];
export var GetProductsRequest$ = [3, n0, _GPR,
    0,
    [_SC, _Fil, _FV, _NT, _MR],
    [0, () => Filters, 0, 0, 1], 1
];
export var GetProductsResponse$ = [3, n0, _GPRe,
    0,
    [_FV, _PL, _NT],
    [0, [() => PriceListJsonItems, 0], 0]
];
export var ListPriceListsRequest$ = [3, n0, _LPLR,
    0,
    [_SC, _ED, _CC, _RC, _NT, _MR],
    [0, 4, 0, 0, 0, 1], 3
];
export var ListPriceListsResponse$ = [3, n0, _LPLRi,
    0,
    [_PLr, _NT],
    [() => PriceLists, 0]
];
export var PriceList$ = [3, n0, _PL,
    0,
    [_PLA, _RC, _CC, _FFi],
    [0, 0, 0, 64 | 0]
];
export var Service$ = [3, n0, _Se,
    0,
    [_SC, _ANt],
    [0, 64 | 0], 1
];
var AttributeNameList = 64 | 0;
var AttributeValueList = [1, n0, _AVL,
    0, () => AttributeValue$
];
var FileFormats = 64 | 0;
var Filters = [1, n0, _Fil,
    0, () => Filter$
];
var PriceListJsonItems = [1, n0, _PLJI,
    0, [() => SynthesizedJsonPriceListJsonItem,
        0]
];
var PriceLists = [1, n0, _PLr,
    0, () => PriceList$
];
var ServiceList = [1, n0, _SL,
    0, () => Service$
];
export var DescribeServices$ = [9, n0, _DS,
    0, () => DescribeServicesRequest$, () => DescribeServicesResponse$
];
export var GetAttributeValues$ = [9, n0, _GAV,
    0, () => GetAttributeValuesRequest$, () => GetAttributeValuesResponse$
];
export var GetPriceListFileUrl$ = [9, n0, _GPLFU,
    0, () => GetPriceListFileUrlRequest$, () => GetPriceListFileUrlResponse$
];
export var GetProducts$ = [9, n0, _GP,
    0, () => GetProductsRequest$, () => GetProductsResponse$
];
export var ListPriceLists$ = [9, n0, _LPL,
    0, () => ListPriceListsRequest$, () => ListPriceListsResponse$
];
