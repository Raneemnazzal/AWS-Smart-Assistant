import type { Paginator } from "@smithy/types";
import { DescribeServicesCommandInput, DescribeServicesCommandOutput } from "../commands/DescribeServicesCommand";
import type { PricingPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateDescribeServices: (config: PricingPaginationConfiguration, input: DescribeServicesCommandInput, ...rest: any[]) => Paginator<DescribeServicesCommandOutput>;
