import type { Paginator } from "@smithy/types";
import { GetAttributeValuesCommandInput, GetAttributeValuesCommandOutput } from "../commands/GetAttributeValuesCommand";
import type { PricingPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateGetAttributeValues: (config: PricingPaginationConfiguration, input: GetAttributeValuesCommandInput, ...rest: any[]) => Paginator<GetAttributeValuesCommandOutput>;
