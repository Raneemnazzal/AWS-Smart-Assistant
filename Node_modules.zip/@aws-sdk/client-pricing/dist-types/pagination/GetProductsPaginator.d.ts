import type { Paginator } from "@smithy/types";
import { GetProductsCommandInput, GetProductsCommandOutput } from "../commands/GetProductsCommand";
import type { PricingPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateGetProducts: (config: PricingPaginationConfiguration, input: GetProductsCommandInput, ...rest: any[]) => Paginator<GetProductsCommandOutput>;
