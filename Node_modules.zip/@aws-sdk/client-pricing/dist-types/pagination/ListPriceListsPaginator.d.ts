import type { Paginator } from "@smithy/types";
import { ListPriceListsCommandInput, ListPriceListsCommandOutput } from "../commands/ListPriceListsCommand";
import type { PricingPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateListPriceLists: (config: PricingPaginationConfiguration, input: ListPriceListsCommandInput, ...rest: any[]) => Paginator<ListPriceListsCommandOutput>;
