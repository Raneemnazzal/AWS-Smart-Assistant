import { TypeRegistry } from "@smithy/core/schema";
import type { StaticErrorSchema, StaticOperationSchema, StaticStructureSchema } from "@smithy/types";
export declare var PricingServiceException$: StaticErrorSchema;
export declare var AccessDeniedException$: StaticErrorSchema;
export declare var ExpiredNextTokenException$: StaticErrorSchema;
export declare var InternalErrorException$: StaticErrorSchema;
export declare var InvalidNextTokenException$: StaticErrorSchema;
export declare var InvalidParameterException$: StaticErrorSchema;
export declare var NotFoundException$: StaticErrorSchema;
export declare var ResourceNotFoundException$: StaticErrorSchema;
export declare var ThrottlingException$: StaticErrorSchema;
/**
 * TypeRegistry instances containing modeled errors.
 * @internal
 *
 */
export declare const errorTypeRegistries: TypeRegistry[];
export declare var AttributeValue$: StaticStructureSchema;
export declare var DescribeServicesRequest$: StaticStructureSchema;
export declare var DescribeServicesResponse$: StaticStructureSchema;
export declare var Filter$: StaticStructureSchema;
export declare var GetAttributeValuesRequest$: StaticStructureSchema;
export declare var GetAttributeValuesResponse$: StaticStructureSchema;
export declare var GetPriceListFileUrlRequest$: StaticStructureSchema;
export declare var GetPriceListFileUrlResponse$: StaticStructureSchema;
export declare var GetProductsRequest$: StaticStructureSchema;
export declare var GetProductsResponse$: StaticStructureSchema;
export declare var ListPriceListsRequest$: StaticStructureSchema;
export declare var ListPriceListsResponse$: StaticStructureSchema;
export declare var PriceList$: StaticStructureSchema;
export declare var Service$: StaticStructureSchema;
export declare var DescribeServices$: StaticOperationSchema;
export declare var GetAttributeValues$: StaticOperationSchema;
export declare var GetPriceListFileUrl$: StaticOperationSchema;
export declare var GetProducts$: StaticOperationSchema;
export declare var ListPriceLists$: StaticOperationSchema;
