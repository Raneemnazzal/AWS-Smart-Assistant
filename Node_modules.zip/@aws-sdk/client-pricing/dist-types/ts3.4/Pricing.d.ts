import {
  HttpHandlerOptions as __HttpHandlerOptions,
  MetricsRecorder as __MetricsRecorder,
  PaginationConfiguration,
  Paginator,
} from "@smithy/types";
import {
  DescribeServicesCommandInput,
  DescribeServicesCommandOutput,
} from "./commands/DescribeServicesCommand";
import {
  GetAttributeValuesCommandInput,
  GetAttributeValuesCommandOutput,
} from "./commands/GetAttributeValuesCommand";
import {
  GetPriceListFileUrlCommandInput,
  GetPriceListFileUrlCommandOutput,
} from "./commands/GetPriceListFileUrlCommand";
import { GetProductsCommandInput, GetProductsCommandOutput } from "./commands/GetProductsCommand";
import {
  ListPriceListsCommandInput,
  ListPriceListsCommandOutput,
} from "./commands/ListPriceListsCommand";
import { PricingClient } from "./PricingClient";
export interface PricingRequestOptions extends __HttpHandlerOptions {
  metricsRecorder?: __MetricsRecorder<unknown>;
}
export interface Pricing {
  describeServices(): Promise<DescribeServicesCommandOutput>;
  describeServices(
    args: DescribeServicesCommandInput,
    options?: PricingRequestOptions,
  ): Promise<DescribeServicesCommandOutput>;
  describeServices(
    args: DescribeServicesCommandInput,
    cb: (err: any, data?: DescribeServicesCommandOutput) => void,
  ): void;
  describeServices(
    args: DescribeServicesCommandInput,
    options: PricingRequestOptions,
    cb: (err: any, data?: DescribeServicesCommandOutput) => void,
  ): void;
  getAttributeValues(
    args: GetAttributeValuesCommandInput,
    options?: PricingRequestOptions,
  ): Promise<GetAttributeValuesCommandOutput>;
  getAttributeValues(
    args: GetAttributeValuesCommandInput,
    cb: (err: any, data?: GetAttributeValuesCommandOutput) => void,
  ): void;
  getAttributeValues(
    args: GetAttributeValuesCommandInput,
    options: PricingRequestOptions,
    cb: (err: any, data?: GetAttributeValuesCommandOutput) => void,
  ): void;
  getPriceListFileUrl(
    args: GetPriceListFileUrlCommandInput,
    options?: PricingRequestOptions,
  ): Promise<GetPriceListFileUrlCommandOutput>;
  getPriceListFileUrl(
    args: GetPriceListFileUrlCommandInput,
    cb: (err: any, data?: GetPriceListFileUrlCommandOutput) => void,
  ): void;
  getPriceListFileUrl(
    args: GetPriceListFileUrlCommandInput,
    options: PricingRequestOptions,
    cb: (err: any, data?: GetPriceListFileUrlCommandOutput) => void,
  ): void;
  getProducts(
    args: GetProductsCommandInput,
    options?: PricingRequestOptions,
  ): Promise<GetProductsCommandOutput>;
  getProducts(
    args: GetProductsCommandInput,
    cb: (err: any, data?: GetProductsCommandOutput) => void,
  ): void;
  getProducts(
    args: GetProductsCommandInput,
    options: PricingRequestOptions,
    cb: (err: any, data?: GetProductsCommandOutput) => void,
  ): void;
  listPriceLists(
    args: ListPriceListsCommandInput,
    options?: PricingRequestOptions,
  ): Promise<ListPriceListsCommandOutput>;
  listPriceLists(
    args: ListPriceListsCommandInput,
    cb: (err: any, data?: ListPriceListsCommandOutput) => void,
  ): void;
  listPriceLists(
    args: ListPriceListsCommandInput,
    options: PricingRequestOptions,
    cb: (err: any, data?: ListPriceListsCommandOutput) => void,
  ): void;
  paginateDescribeServices(
    args?: DescribeServicesCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<DescribeServicesCommandOutput>;
  paginateGetAttributeValues(
    args: GetAttributeValuesCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<GetAttributeValuesCommandOutput>;
  paginateGetProducts(
    args: GetProductsCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<GetProductsCommandOutput>;
  paginateListPriceLists(
    args: ListPriceListsCommandInput,
    paginationConfig?: Pick<
      PaginationConfiguration,
      Exclude<keyof PaginationConfiguration, "client">
    >,
  ): Paginator<ListPriceListsCommandOutput>;
}
export declare class Pricing extends PricingClient implements Pricing {}
