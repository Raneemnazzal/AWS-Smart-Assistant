import {
  AwsSdkSigV4AuthInputConfig,
  AwsSdkSigV4AuthResolvedConfig,
  AwsSdkSigV4PreviouslyResolved,
} from "@aws-sdk/core/httpAuthSchemes";
import {
  HandlerExecutionContext,
  HttpAuthScheme,
  HttpAuthSchemeParameters,
  HttpAuthSchemeParametersProvider,
  HttpAuthSchemeProvider,
  Provider,
} from "@smithy/types";
import { PricingClientResolvedConfig } from "../PricingClient";
export interface PricingHttpAuthSchemeParameters extends HttpAuthSchemeParameters {
  region?: string;
}
export interface PricingHttpAuthSchemeParametersProvider extends HttpAuthSchemeParametersProvider<
  PricingClientResolvedConfig,
  HandlerExecutionContext,
  PricingHttpAuthSchemeParameters,
  object
> {}
export declare const defaultPricingHttpAuthSchemeParametersProvider: (
  config: PricingClientResolvedConfig,
  context: HandlerExecutionContext,
  input: object,
) => Promise<PricingHttpAuthSchemeParameters>;
export interface PricingHttpAuthSchemeProvider extends HttpAuthSchemeProvider<PricingHttpAuthSchemeParameters> {}
export declare const defaultPricingHttpAuthSchemeProvider: PricingHttpAuthSchemeProvider;
export interface HttpAuthSchemeInputConfig extends AwsSdkSigV4AuthInputConfig {
  authSchemePreference?: string[] | Provider<string[]>;
  httpAuthSchemes?: HttpAuthScheme[];
  httpAuthSchemeProvider?: PricingHttpAuthSchemeProvider;
}
export interface HttpAuthSchemeResolvedConfig extends AwsSdkSigV4AuthResolvedConfig {
  readonly authSchemePreference: Provider<string[]>;
  readonly httpAuthSchemes: HttpAuthScheme[];
  readonly httpAuthSchemeProvider: PricingHttpAuthSchemeProvider;
}
export declare const resolveHttpAuthSchemeConfig: <T>(
  config: T & HttpAuthSchemeInputConfig & AwsSdkSigV4PreviouslyResolved,
) => T & HttpAuthSchemeResolvedConfig;
