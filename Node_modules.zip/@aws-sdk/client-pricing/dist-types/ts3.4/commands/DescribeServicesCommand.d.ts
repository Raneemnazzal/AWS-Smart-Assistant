import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { DescribeServicesRequest, DescribeServicesResponse } from "../models/models_0";
export { __MetadataBearer };
export interface DescribeServicesCommandInput extends DescribeServicesRequest {}
export interface DescribeServicesCommandOutput extends DescribeServicesResponse, __MetadataBearer {}
declare const DescribeServicesCommand_base: {
  new (
    input: DescribeServicesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    DescribeServicesCommandInput,
    DescribeServicesCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    ...[input]: [] | [DescribeServicesCommandInput]
  ): import("@smithy/core/client").CommandImpl<
    DescribeServicesCommandInput,
    DescribeServicesCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class DescribeServicesCommand extends DescribeServicesCommand_base {
  protected static __types: {
    api: {
      input: DescribeServicesRequest;
      output: DescribeServicesResponse;
    };
    sdk: {
      input: DescribeServicesCommandInput;
      output: DescribeServicesCommandOutput;
    };
  };
}
