import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetAttributeValuesRequest, GetAttributeValuesResponse } from "../models/models_0";
export { __MetadataBearer };
export interface GetAttributeValuesCommandInput extends GetAttributeValuesRequest {}
export interface GetAttributeValuesCommandOutput
  extends GetAttributeValuesResponse, __MetadataBearer {}
declare const GetAttributeValuesCommand_base: {
  new (
    input: GetAttributeValuesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetAttributeValuesCommandInput,
    GetAttributeValuesCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetAttributeValuesCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetAttributeValuesCommandInput,
    GetAttributeValuesCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetAttributeValuesCommand extends GetAttributeValuesCommand_base {
  protected static __types: {
    api: {
      input: GetAttributeValuesRequest;
      output: GetAttributeValuesResponse;
    };
    sdk: {
      input: GetAttributeValuesCommandInput;
      output: GetAttributeValuesCommandOutput;
    };
  };
}
