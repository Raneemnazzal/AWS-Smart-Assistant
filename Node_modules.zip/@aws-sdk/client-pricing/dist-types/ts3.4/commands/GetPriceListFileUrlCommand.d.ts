import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetPriceListFileUrlRequest, GetPriceListFileUrlResponse } from "../models/models_0";
export { __MetadataBearer };
export interface GetPriceListFileUrlCommandInput extends GetPriceListFileUrlRequest {}
export interface GetPriceListFileUrlCommandOutput
  extends GetPriceListFileUrlResponse, __MetadataBearer {}
declare const GetPriceListFileUrlCommand_base: {
  new (
    input: GetPriceListFileUrlCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetPriceListFileUrlCommandInput,
    GetPriceListFileUrlCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetPriceListFileUrlCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetPriceListFileUrlCommandInput,
    GetPriceListFileUrlCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetPriceListFileUrlCommand extends GetPriceListFileUrlCommand_base {
  protected static __types: {
    api: {
      input: GetPriceListFileUrlRequest;
      output: GetPriceListFileUrlResponse;
    };
    sdk: {
      input: GetPriceListFileUrlCommandInput;
      output: GetPriceListFileUrlCommandOutput;
    };
  };
}
