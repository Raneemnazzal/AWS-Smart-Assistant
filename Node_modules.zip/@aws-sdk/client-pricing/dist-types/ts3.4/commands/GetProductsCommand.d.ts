import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { GetProductsRequest, GetProductsResponse } from "../models/models_0";
export { __MetadataBearer };
export interface GetProductsCommandInput extends GetProductsRequest {}
export interface GetProductsCommandOutput extends GetProductsResponse, __MetadataBearer {}
declare const GetProductsCommand_base: {
  new (
    input: GetProductsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetProductsCommandInput,
    GetProductsCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: GetProductsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    GetProductsCommandInput,
    GetProductsCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class GetProductsCommand extends GetProductsCommand_base {
  protected static __types: {
    api: {
      input: GetProductsRequest;
      output: GetProductsResponse;
    };
    sdk: {
      input: GetProductsCommandInput;
      output: GetProductsCommandOutput;
    };
  };
}
