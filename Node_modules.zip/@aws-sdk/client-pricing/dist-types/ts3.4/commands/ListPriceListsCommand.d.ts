import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import { ListPriceListsRequest, ListPriceListsResponse } from "../models/models_0";
export { __MetadataBearer };
export interface ListPriceListsCommandInput extends ListPriceListsRequest {}
export interface ListPriceListsCommandOutput extends ListPriceListsResponse, __MetadataBearer {}
declare const ListPriceListsCommand_base: {
  new (
    input: ListPriceListsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ListPriceListsCommandInput,
    ListPriceListsCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  new (
    input: ListPriceListsCommandInput,
  ): import("@smithy/core/client").CommandImpl<
    ListPriceListsCommandInput,
    ListPriceListsCommandOutput,
    import("..").PricingClientResolvedConfig,
    import("..").ServiceInputTypes,
    import("..").ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): import("@smithy/types").EndpointParameterInstructions;
};
export declare class ListPriceListsCommand extends ListPriceListsCommand_base {
  protected static __types: {
    api: {
      input: ListPriceListsRequest;
      output: ListPriceListsResponse;
    };
    sdk: {
      input: ListPriceListsCommandInput;
      output: ListPriceListsCommandOutput;
    };
  };
}
