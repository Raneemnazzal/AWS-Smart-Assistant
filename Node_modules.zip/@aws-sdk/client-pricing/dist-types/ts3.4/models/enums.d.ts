export declare const FilterType: {
  readonly ANY_OF: "ANY_OF";
  readonly CONTAINS: "CONTAINS";
  readonly EQUALS: "EQUALS";
  readonly NONE_OF: "NONE_OF";
  readonly TERM_MATCH: "TERM_MATCH";
};
export type FilterType = (typeof FilterType)[keyof typeof FilterType];
