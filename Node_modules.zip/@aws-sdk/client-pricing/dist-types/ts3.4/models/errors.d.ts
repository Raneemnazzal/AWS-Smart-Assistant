import { ExceptionOptionType as __ExceptionOptionType } from "@smithy/core/client";
import { PricingServiceException as __BaseException } from "./PricingServiceException";
export declare class AccessDeniedException extends __BaseException {
  readonly name: "AccessDeniedException";
  readonly $fault: "client";
  Message?: string | undefined;
  constructor(opts: __ExceptionOptionType<AccessDeniedException, __BaseException>);
}
export declare class ExpiredNextTokenException extends __BaseException {
  readonly name: "ExpiredNextTokenException";
  readonly $fault: "client";
  Message?: string | undefined;
  constructor(opts: __ExceptionOptionType<ExpiredNextTokenException, __BaseException>);
}
export declare class InternalErrorException extends __BaseException {
  readonly name: "InternalErrorException";
  readonly $fault: "server";
  $retryable: {};
  Message?: string | undefined;
  constructor(opts: __ExceptionOptionType<InternalErrorException, __BaseException>);
}
export declare class InvalidNextTokenException extends __BaseException {
  readonly name: "InvalidNextTokenException";
  readonly $fault: "client";
  Message?: string | undefined;
  constructor(opts: __ExceptionOptionType<InvalidNextTokenException, __BaseException>);
}
export declare class InvalidParameterException extends __BaseException {
  readonly name: "InvalidParameterException";
  readonly $fault: "client";
  Message?: string | undefined;
  constructor(opts: __ExceptionOptionType<InvalidParameterException, __BaseException>);
}
export declare class NotFoundException extends __BaseException {
  readonly name: "NotFoundException";
  readonly $fault: "client";
  Message?: string | undefined;
  constructor(opts: __ExceptionOptionType<NotFoundException, __BaseException>);
}
export declare class ThrottlingException extends __BaseException {
  readonly name: "ThrottlingException";
  readonly $fault: "client";
  $retryable: {
    throttling: boolean;
  };
  Message?: string | undefined;
  constructor(opts: __ExceptionOptionType<ThrottlingException, __BaseException>);
}
export declare class ResourceNotFoundException extends __BaseException {
  readonly name: "ResourceNotFoundException";
  readonly $fault: "client";
  Message?: string | undefined;
  constructor(opts: __ExceptionOptionType<ResourceNotFoundException, __BaseException>);
}
