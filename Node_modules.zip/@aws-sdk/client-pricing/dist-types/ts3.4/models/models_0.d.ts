import { AutomaticJsonStringConversion as __AutomaticJsonStringConversion } from "@smithy/core/serde";
import { FilterType } from "./enums";
export interface AttributeValue {
  Value?: string | undefined;
}
export interface DescribeServicesRequest {
  ServiceCode?: string | undefined;
  FormatVersion?: string | undefined;
  NextToken?: string | undefined;
  MaxResults?: number | undefined;
}
export interface Service {
  ServiceCode: string | undefined;
  AttributeNames?: string[] | undefined;
}
export interface DescribeServicesResponse {
  Services?: Service[] | undefined;
  FormatVersion?: string | undefined;
  NextToken?: string | undefined;
}
export interface GetAttributeValuesRequest {
  ServiceCode: string | undefined;
  AttributeName: string | undefined;
  NextToken?: string | undefined;
  MaxResults?: number | undefined;
}
export interface GetAttributeValuesResponse {
  AttributeValues?: AttributeValue[] | undefined;
  NextToken?: string | undefined;
}
export interface GetPriceListFileUrlRequest {
  PriceListArn: string | undefined;
  FileFormat: string | undefined;
}
export interface GetPriceListFileUrlResponse {
  Url?: string | undefined;
}
export interface Filter {
  Type: FilterType | undefined;
  Field: string | undefined;
  Value: string | undefined;
}
export interface GetProductsRequest {
  ServiceCode: string | undefined;
  Filters?: Filter[] | undefined;
  FormatVersion?: string | undefined;
  NextToken?: string | undefined;
  MaxResults?: number | undefined;
}
export interface GetProductsResponse {
  FormatVersion?: string | undefined;
  PriceList?: __AutomaticJsonStringConversion | string[] | undefined;
  NextToken?: string | undefined;
}
export interface ListPriceListsRequest {
  ServiceCode: string | undefined;
  EffectiveDate: Date | undefined;
  RegionCode?: string | undefined;
  CurrencyCode: string | undefined;
  NextToken?: string | undefined;
  MaxResults?: number | undefined;
}
export interface PriceList {
  PriceListArn?: string | undefined;
  RegionCode?: string | undefined;
  CurrencyCode?: string | undefined;
  FileFormats?: string[] | undefined;
}
export interface ListPriceListsResponse {
  PriceLists?: PriceList[] | undefined;
  NextToken?: string | undefined;
}
