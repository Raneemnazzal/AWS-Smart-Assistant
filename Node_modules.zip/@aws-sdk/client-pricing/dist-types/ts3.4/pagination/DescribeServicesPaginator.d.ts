import { Paginator } from "@smithy/types";
import {
  DescribeServicesCommandInput,
  DescribeServicesCommandOutput,
} from "../commands/DescribeServicesCommand";
import { PricingPaginationConfiguration } from "./Interfaces";
export declare const paginateDescribeServices: (
  config: PricingPaginationConfiguration,
  input: DescribeServicesCommandInput,
  ...rest: any[]
) => Paginator<DescribeServicesCommandOutput>;
