import { Paginator } from "@smithy/types";
import {
  GetAttributeValuesCommandInput,
  GetAttributeValuesCommandOutput,
} from "../commands/GetAttributeValuesCommand";
import { PricingPaginationConfiguration } from "./Interfaces";
export declare const paginateGetAttributeValues: (
  config: PricingPaginationConfiguration,
  input: GetAttributeValuesCommandInput,
  ...rest: any[]
) => Paginator<GetAttributeValuesCommandOutput>;
