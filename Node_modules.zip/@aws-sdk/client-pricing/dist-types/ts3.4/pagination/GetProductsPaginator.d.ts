import { Paginator } from "@smithy/types";
import { GetProductsCommandInput, GetProductsCommandOutput } from "../commands/GetProductsCommand";
import { PricingPaginationConfiguration } from "./Interfaces";
export declare const paginateGetProducts: (
  config: PricingPaginationConfiguration,
  input: GetProductsCommandInput,
  ...rest: any[]
) => Paginator<GetProductsCommandOutput>;
