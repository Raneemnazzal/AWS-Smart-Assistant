import { PaginationConfiguration } from "@smithy/types";
import { PricingClient } from "../PricingClient";
export interface PricingPaginationConfiguration extends PaginationConfiguration {
  client: PricingClient;
}
