import { Paginator } from "@smithy/types";
import {
  ListPriceListsCommandInput,
  ListPriceListsCommandOutput,
} from "../commands/ListPriceListsCommand";
import { PricingPaginationConfiguration } from "./Interfaces";
export declare const paginateListPriceLists: (
  config: PricingPaginationConfiguration,
  input: ListPriceListsCommandInput,
  ...rest: any[]
) => Paginator<ListPriceListsCommandOutput>;
